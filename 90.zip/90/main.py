import pygame as pg
import random
import os

SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
LANE_COUNT = 8
LANE_HEIGHT = SCREEN_HEIGHT // LANE_COUNT
FPS = 60
MONEY_PER_SECOND = 23
MAX_HEALTH = 100
ENEMY_BASE_HEALTH = 1000

pg.init()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("RTS Lane Defense")
clock = pg.time.Clock()

RESOURCE_DIR = "resources"
BACKGROUND_IMAGE = os.path.join(RESOURCE_DIR, "background.png")
WARRIOR_IMAGES = {
    "light": os.path.join(RESOURCE_DIR, "warrior_light.png"),
    "medium": os.path.join(RESOURCE_DIR, "warrior_medium.png"),
    "heavy": os.path.join(RESOURCE_DIR, "warrior_heavy.png"),
}
ENEMY_IMAGES = {
    "small": os.path.join(RESOURCE_DIR, "enemy_small.png"),
    "medium": os.path.join(RESOURCE_DIR, "enemy_medium.png"),
    "large": os.path.join(RESOURCE_DIR, "enemy_large.png"),
}

background = pg.image.load(BACKGROUND_IMAGE)
background = pg.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))

warrior_images = {
    warrior_type: pg.transform.scale(pg.image.load(path), (40, 40))
    for warrior_type, path in WARRIOR_IMAGES.items()
}

enemy_images = {
    enemy_type: pg.transform.scale(pg.image.load(path), (40, 40))
    for enemy_type, path in ENEMY_IMAGES.items()
}


class Enemy(pg.sprite.Sprite):
    def __init__(self, lane, enemy_type, health, speed):
        super().__init__()
        self.image = enemy_images[enemy_type].copy()
        self.rect = self.image.get_rect()
        self.rect.x = SCREEN_WIDTH - 50
        self.rect.y = lane * LANE_HEIGHT + (LANE_HEIGHT - self.rect.height) // 2
        self.health = health
        self.speed = speed
        self.lane = lane
        self.position_x = float(self.rect.x)

    def update(self):
        self.position_x -= self.speed
        self.rect.x = int(self.position_x)
        if self.health <= 0 or self.rect.x < 0:
            self.kill()

    def reached_end(self):
        return self.rect.x <= 0


class Warrior(pg.sprite.Sprite):
    def __init__(self, lane, warrior_type, health, speed, cost):
        super().__init__()
        self.image = warrior_images[warrior_type].copy()
        self.rect = self.image.get_rect()
        self.rect.x = 10
        self.rect.y = lane * LANE_HEIGHT + (LANE_HEIGHT - self.rect.height) // 2
        self.health = health
        self.speed = speed
        self.cost = cost
        self.lane = lane
        self.position_x = float(self.rect.x)

    def update(self):
        self.position_x += self.speed
        self.rect.x = int(self.position_x)
        if self.health <= 0 or self.rect.x > SCREEN_WIDTH:
            self.kill()

    def take_damage(self, damage):
        self.health -= damage
        if self.health <= 0:
            self.kill()


class Game:
    def __init__(self):
        self.all_sprites = pg.sprite.Group()
        self.enemies = pg.sprite.Group()
        self.warriors = pg.sprite.Group()
        self.selected_lane = 0
        self.selected_warrior_type = "light"
        self.money = 100
        self.last_money_update = pg.time.get_ticks()
        self.enemy_spawn_time = 2000
        self.last_enemy_spawn = pg.time.get_ticks()
        self.player_health = MAX_HEALTH
        self.enemy_base_health = ENEMY_BASE_HEALTH
        self.game_over = False
        self.not_enough_money = False
        self.win = False

    def spawn_enemy(self):
        lane = random.randint(0, LANE_COUNT - 1)
        enemy_type = random.choice(["small", "medium", "large"])
        enemy_config = {
            "small": {"health": 50, "speed": 1},
            "medium": {"health": 100, "speed": 0.8},
            "large": {"health": 150, "speed": 0.5},
        }
        config = enemy_config[enemy_type]
        enemy = Enemy(lane, enemy_type, **config)
        self.all_sprites.add(enemy)
        self.enemies.add(enemy)

    def spawn_warrior(self):
        warrior_config = {
            "light": {"health": 100, "speed": 1.5, "cost": 20},
            "medium": {"health": 200, "speed": 1, "cost": 40},
            "heavy": {"health": 300, "speed": 0.8, "cost": 60},
        }
        config = warrior_config[self.selected_warrior_type]

        if self.money >= config["cost"]:
            self.money -= config["cost"]
            warrior = Warrior(self.selected_lane, self.selected_warrior_type, **config)
            self.all_sprites.add(warrior)
            self.warriors.add(warrior)
            self.not_enough_money = False
        else:
            self.not_enough_money = True

    def check_collisions(self):
        for warrior in self.warriors:
            collided_enemies = pg.sprite.spritecollide(warrior, self.enemies, False)
            for enemy in collided_enemies:
                warrior.take_damage(20)
                enemy.health -= 20

    def update_enemy_base_health(self):
        for warrior in self.warriors:
            if warrior.rect.x >= SCREEN_WIDTH:
                self.enemy_base_health -= 50
                warrior.kill()

        if self.enemy_base_health <= 0:
            self.win = True

    def update_money(self):
        now = pg.time.get_ticks()
        if now - self.last_money_update > 1000:
            self.money += MONEY_PER_SECOND
            self.last_money_update = now

    def draw_lanes(self):
        for i in range(LANE_COUNT):
            y = i * LANE_HEIGHT
            pg.draw.line(screen, (255, 255, 255), (0, y), (SCREEN_WIDTH, y))

    def draw_ui(self):
        font = pg.font.Font(None, 36)
        money_text = font.render(f"Money: {self.money}", True, (255, 255, 255))
        screen.blit(money_text, (10, 10))

        warrior_text = font.render(f"Warrior: {self.selected_warrior_type.capitalize()}", True, (255, 255, 255))
        screen.blit(warrior_text, (10, 50))

        health_text = font.render(f"Health: {self.player_health}", True, (255, 0, 0))
        screen.blit(health_text, (SCREEN_WIDTH - 150, 10))

        enemy_base_health_text = font.render(f"Enemy Base HP: {self.enemy_base_health}", True, (255, 255, 255))
        screen.blit(enemy_base_health_text, (10, SCREEN_HEIGHT - 40))

        if self.player_health <= 0:
            self.display_message("GAME OVER")

        if self.not_enough_money:
            self.display_message("НЕХВАТКА ДЕНЕГ")

        if self.win:
            self.display_message("YOU WIN!")

    def display_message(self, message):
        font = pg.font.Font(None, 72)
        text_surface = font.render(message, True, (255, 0, 0))
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        screen.blit(text_surface, text_rect)

    def run(self):
        running = True
        while running:
            screen.blit(background, (0, 0))
            self.draw_lanes()

            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False
                if event.type == pg.KEYUP:
                    if event.key == pg.K_UP:
                        self.selected_lane = (self.selected_lane - 1) % LANE_COUNT
                    elif event.key == pg.K_DOWN:
                        self.selected_lane = (self.selected_lane + 1) % LANE_COUNT
                    elif event.key == pg.K_SPACE:
                        self.spawn_warrior()
                    elif event.key == pg.K_1:
                        self.selected_warrior_type = "light"
                    elif event.key == pg.K_2:
                        self.selected_warrior_type = "medium"
                    elif event.key == pg.K_3:
                        self.selected_warrior_type = "heavy"

            pg.draw.rect(screen, (255, 255, 255), (0, self.selected_lane * LANE_HEIGHT, SCREEN_WIDTH, LANE_HEIGHT), 2)

            now = pg.time.get_ticks()
            if now - self.last_enemy_spawn > self.enemy_spawn_time:
                self.spawn_enemy()
                self.last_enemy_spawn = now
                if self.enemy_spawn_time > 1000:
                    self.enemy_spawn_time -= 100

            self.all_sprites.update()
            self.update_money()
            self.check_collisions()
            self.update_enemy_base_health()

            for enemy in self.enemies:
                if enemy.reached_end():
                    self.player_health -= 10
                    enemy.kill()

            self.all_sprites.draw(screen)
            self.draw_ui()
            pg.display.flip()
            clock.tick(FPS)

            if self.player_health <= 0 or self.win:
                pg.time.wait(2000)
                running = False

        pg.quit()


if __name__ == "__main__":
    Game().run()
